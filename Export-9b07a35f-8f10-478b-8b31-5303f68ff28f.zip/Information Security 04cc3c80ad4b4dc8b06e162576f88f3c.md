# Information Security

[Webgoat](https://www.notion.so/Webgoat-3eda98c47eaa4c03a67f3403d1f48fde)

[OWASP TOP10](https://www.notion.so/OWASP-TOP10-31ff1bd5859d4e8c92939a9236d6bdf3)

[OWASP TOP10 2021](https://www.notion.so/OWASP-TOP10-2021-c160087a38194af488cf24dc325ae863)

[Learn Cybersecurity with bash](https://www.notion.so/Learn-Cybersecurity-with-bash-57c6c87553de4534a83c5647ff19cdec)